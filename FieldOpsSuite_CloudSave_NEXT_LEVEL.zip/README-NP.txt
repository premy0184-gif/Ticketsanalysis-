FieldOps Suite Cloud Save

1. Open PowerShell in this folder.
2. Run: npx wrangler deploy
3. Open your workers.dev URL.
4. PC मा पहिले खोल्दा पुरानो local data भए cloud KV मा migrate हुन्छ।
5. त्यसपछि mobile/other PC मा same data देखिन्छ।
