export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/kv" || url.pathname.startsWith("/api/kv/")) {
      return handleKV(request, env.DATA, url);
    }
    return env.ASSETS.fetch(request);
  }
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*"
    }
  });
}

async function handleKV(request, kv, url) {
  const path = url.pathname;
  if (request.method === "OPTIONS") {
    return new Response(null, { headers: {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,PUT,DELETE,OPTIONS",
      "access-control-allow-headers": "content-type"
    }});
  }
  if (path === "/api/kv" && request.method === "GET") {
    const prefix = url.searchParams.get("prefix") || "";
    const list = await kv.list({ prefix, limit: 1000 });
    return json({ keys: list.keys.map(k => k.name) });
  }
  if (!path.startsWith("/api/kv/")) return json({ ok: true });
  const key = decodeURIComponent(path.slice("/api/kv/".length));
  if (!key) return json({ error: "Missing key" }, 400);
  if (request.method === "GET") {
    const value = await kv.get(key);
    return json({ value: value === null ? null : value });
  }
  if (request.method === "PUT") {
    const body = await request.json().catch(() => null);
    if (!body || typeof body.value !== "string") return json({ error: "value must be a string" }, 400);
    await kv.put(key, body.value);
    return json({ ok: true });
  }
  if (request.method === "DELETE") {
    await kv.delete(key);
    return json({ ok: true });
  }
  return json({ error: "Method not allowed" }, 405);
}
